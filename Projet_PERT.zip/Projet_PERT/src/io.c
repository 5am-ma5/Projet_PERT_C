#include "list.h"
#include "elmlist.h"
#include "job.h"
#include "outils.h"
#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions
#include <string.h> 


typedef enum file_mode { TEXT, BINARY } file_mode_t;



list_t * read_graph ( char * filename ) {
    FILE * fd = fopen ( filename, "rt" );
    list_t * G = new_list ( );
    assert ( fd && G );
    char job_name [ BUFSIZ ];

    while ( !feof ( fd ) ) {

        fscanf ( fd, " %s", job_name);
        if ( !strcmp (job_name, "NIL" ) ) continue;

        job_t * J = new_job ( job_name );

	/** @note
	    À l'appel J pointe sur le job que l'on vient de créer.
	    
	    FIND retrouve le job J dans la liste G des jobs grâce à la fonction titleJobCmp.
	    Si ce job n'est pas dans la liste G alors
	        le job pointé par J est enregistré dans G
	    Si ce job est déjà dans G alors
	        le job pointé par J est supprimé grâce à free_job
		puis le pointeur de J est réassigné sur le job trouvé dans G
	 */
	find ( G, ( void ** ) &J, &titleJobCmp, &free_job );

	fscanf ( fd, "%lf", &(J->life) );

	/** @note
	    Enregistrement des préséances
	*/
	job_t * predJ;
	fscanf( fd, " %s", job_name );
	while ( strcmp ( job_name, "NIL" ) ) {
	  predJ = new_job ( job_name );
    
	  find ( G, (void **) &predJ, &titleJobCmp, &free_job );

	  cons ( predJ->posteriority, J);
	  incr_job_oDegree ( predJ );

	  cons ( J->precedence, predJ);
	  incr_job_iDegree ( J );

	  fscanf ( fd, " %s", job_name );
	}
	
	/** @note valeurs par défaut des autres champs */
        J->dyn_input_degree = J->input_degree;
        J->rank = UNDEF;
        J->au_plus_tard = UNDEF;
        J->au_plus_tot = UNDEF;
        J->marge_totale = UNDEF;
        J->critique = false;
    }
    return G;
}





