#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions
#include "elmlist.h"
#include "list.h"
#include "job.h"
#include "rank.h"

//**************************************************************************************
// RANKING
//**************************************************************************************

// truc privé
bool precedentJobsFinished(job_t * J, int rang) {
    bool res = true;
    elmlist_t * E = get_head(J->precedence);
    
    // on parcourt
    while(res && E) {
        
        job_t * job = (job_t*) get_data(E);
        int jobRank = get_job_rank(job);

        if ((jobRank == rang) || (jobRank == UNDEF) )
            res = false;

        E = get_suc(E);
    }
    return res;
}

void rankingJob(job_t * J, int rang) {
    set_rank(J, rang);
    elmlist_t * E = get_head(J->posteriority);
    
    // on parcourt la posteriority
    while(E) {
        job_t * job = (job_t*) get_data(E);

        if (precedentJobsFinished(job, rang + 1)) {
            rankingJob(job, rang + 1);
        }
        E = get_suc(E);
    }
}

void ranking(list_t * G) {
    // rangs de chaque sommets
    assert(G);

    // on ajoute le noeud omega en fin de liste
    creationOmega(G);

    elmlist_t * E = get_head(G);
    
    // on parcourt
    while(E) {
        job_t * job = (job_t*) get_data(E);
        if(is_empty(job->precedence)) {
            rankingJob(job, 0);
        }
        E = get_suc(E);
    }
    // tri par rang
    quick_sort(G, &rangJobCmp);
}  


//**************************************************************************************
//
// PRUNE
// enlève les arcs inutiles (si difference superieur a 1 alors inutiles) 
//
//
//**************************************************************************************

void pruneJob(job_t * J) {
    elmlist_t * E = get_head(J->posteriority);

    int beginRank = get_job_rank(J);

    // on parcourt
    while(E) {
        job_t * job = (job_t*) get_data(E);

        int endRank = get_job_rank(job);

        if ((endRank - beginRank) > 1) {
            // on mémorise le job a retirer
            elmlist_t * temp = E;
            
            // on passe au job suivant à vérifier
            E = get_suc (E);

            // On retire le job de la posteriority de J
            removeElmt(&temp, J->posteriority, NULL);

            // On retire J de la précédence du job retiré
            take_out(job->precedence, J);
        }
        else {
            E = get_suc(E);
        }
    }
}

void prune(list_t * G) {
    elmlist_t * E = get_head(G);

    // on parcourt
    while(E) {
        job_t * job = (job_t*) get_data(E);
        pruneJob(job);
        E = get_suc(E);
    }
}     
//**************************************************************************************
//
// MARGING
// marges de temps autorisés pour chaque tâches 
//
//
//**************************************************************************************

void calculAuPlusTot(job_t * J) {
    double res = 0;

    // on parcourt la precedence de J
    elmlist_t * E = get_head(J->precedence);
    while(E) {
        // pour chaque job précédent on prend le au plus tot ajouté de la durée
        job_t * job = (job_t*) get_data(E);
        double date = get_job_auPlusTot(job) + get_job_life(job);

        // On ne garde que le max
        if (res < date) {
            res = date;
        }
        E = get_suc(E);
    }
    set_auPlusTot(J, res);
}

void calculAuPlusTard(job_t * J) {
    double res;

    // on prend le premier successeur
    elmlist_t * E = get_head(J->posteriority);
    // On prend le job ...
    job_t * job = (job_t*) get_data(E);
    // On fait le premier calcul de marge pour initailiser le calcul du min
    res = get_job_auPlusTard(job) - get_job_life(J);

    // On continue avec tous les successeurs en prenant le min
    E = get_suc(E);

    while(E) {
        // pour chaque job précédent on prend le au plus tot ajouté de la durée
        job_t * job = (job_t*) get_data(E);

        double date = get_job_auPlusTard(job) - get_job_life(J);

        // On ne garde que le min
        if (res > date) {
            res = date;
        }
        E = get_suc(E);
    }
    set_auPlusTard(J, res);
}

void calculMT(job_t * J) {
   
    set_MT(J, get_job_auPlusTard(J) - get_job_auPlusTot(J));
}

void calculMargeLibre(job_t * J) {
    double res;

    // on prend le premier successeur
    elmlist_t * E = get_head(J->posteriority);

    // On prend le job ...
    job_t * job = (job_t*) get_data(E);

    // On fait le premier calcul de marge pour initailiser le calcul du min
    res = get_job_auPlusTot(job) - get_job_auPlusTot(J) - get_job_life(J);

    // On continue avec tous les successeurs en prenant le min
    E = get_suc(E);

    while(E) {
        // pour chaque job précédent on prend le au plus tot ajouté de la durée
        job_t * job = (job_t*) get_data(E);

        double marge = get_job_auPlusTot(job) - get_job_auPlusTot(J) - get_job_life(J);

        // On ne garde que le min
        if (res > marge) {
            res = marge;
        }
        E = get_suc(E);
    }
    set_MargeLibre(J, res);
}

void marges(list_t * G) { 
    assert(G);

    // Au plus tôt ...
    elmlist_t * E = get_head(G);
    
    // on parcourt tous les jobs
    while(E) {
        job_t * job = (job_t*) get_data(E);

        // On calcule la date au plus tot pour ce job
        calculAuPlusTot(job);

        // au suivant
        E = get_suc(E);
    }
    // Au plus tard ...
    E = get_tail(G);

    job_t * omega = (job_t *) get_data (E);
    set_auPlusTard (omega, get_job_auPlusTot (omega));
    
    E = get_pred(E);

    // on parcourt tous les jobs
    while(E) {
        job_t * job = (job_t*) get_data(E);

        // On calcule la date au plus tard pour ce job
        calculAuPlusTard(job);

        // au précédent
        E = get_pred(E);
    }
    // Au plus tôt ...
    E = get_head(G);
    // on parcourt tous les jobs
    while(E) {
        job_t * job = (job_t*) get_data(E);

        // On calcule la marge Totale pour ce job
        calculMT(job);

        // au précédent
        E = get_suc(E);
    }
    // marge Libre au commence a la fin...
    E = get_tail(G);

    omega = (job_t *) get_data (E);
    set_MargeLibre (omega, 0);
    
    E = get_pred(E);

    // on parcourt tous les jobs
    while(E) {
        job_t * job = (job_t*) get_data(E);

        // On calcule la Marge Libre pour ce job
        calculMargeLibre(job);

        // au précédent
        E = get_pred(E);
    }
}    

// tout cela expliquer dans le pdf du projet (sauf "prune" pas trouver.... mais expliquer par prof)

// les 3 fonctions a faire
// plus les fonctions dont nous avons besoins dans job.h 
// ne pas tout faire seulement celles utilise dans les fonctions faite par nous)

/***********************************
 * Définitions des fonctions privées
 ***********************************/

 void creationAlpha(list_t * L ) {
    // Vérifie que le pointeur de la liste n'est pas nul
    assert(L);

    // Récupère le premier élément (tête) de la liste
    elmlist_t * E = get_head(L);

    // Crée un nouveau job nommé "alpha"
    job_t * alpha = new_job("alpha");

    // Ajoute le job "alpha" au début de la liste L
    cons(L, alpha);

    // Parcourt la liste initiale
    while(E) {
        // Récupère le job contenu dans l'élément courant
        job_t * job = (job_t*) get_data(E);

        // Si le job n'a pas de précédence (aucun job à exécuter avant lui)
        if(is_empty(job->precedence)) {
            // On ajoute ce job à la postériorité de "alpha"
            cons(alpha->posteriority, job);

            // Et on ajoute "alpha" à la précédence de ce job
            cons(job->precedence, alpha);
        }

        // Passe à l'élément suivant de la liste
        E = get_suc(E);
    }
}


void creationOmega(list_t * L ) {
    // Vérifie que le pointeur de la liste n'est pas nul
    assert(L);

    // Récupère le premier élément (tête) de la liste
    elmlist_t * E = get_head(L);

    // Crée un nouveau job nommé "omega"
    job_t * omega = new_job("omega");

    // Parcourt la liste des jobs existants
    while(E) {
        // Récupère le job contenu dans l'élément courant
        job_t * job = (job_t*) get_data(E);

        // Si le job n’a pas de postériorité (aucun job à exécuter après lui)
        if(is_empty(job->posteriority)) {
            // On ajoute ce job à la précédence de "omega"
            cons(omega->precedence, job);

            // Et on ajoute "omega" à la postériorité de ce job
            cons(job->posteriority, omega);
        }

        // Passe à l’élément suivant de la liste
        E = get_suc(E);
    }

    // Ajoute "omega" à la fin de la liste
    queue(L, omega);
}
