#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions
#include "elmlist.h"
#include "list.h"

// ROMAIN
#include "job.h"



/*********************************
DÉCLARATIONS DES FONCTIONS PRIVÉES
*********************************/
/** `insert_after` insère la donnée pointée par `d` dans la liste `L`
    après l'élément pointée par `P` dans cette liste.
    et partitions pour le quick sort ainsi que find 
*/
void insert_after(list_t * L, void * d, elmlist_t * place);

void partition(list_t * L, elmlist_t * R, list_t * B, list_t * H, int (*cmpFct)());

void find(list_t * L, void ** ptrKey, int (*cmpFct)(), void (*delFct)());


/**********************************
DÉFINITIONS DES FONCTIONS PUBLIQUES
**********************************/
bool empty_list(list_t * L ) {
  assert(L);
  return L->numelm == 0;
}

// ROMAIN
bool is_empty(list_t * L) {
  return empty_list (L);
}

list_t * new_list() {
  list_t * L = calloc(1, sizeof(list_t));
  assert(L);
  return L;
}

void del_list(list_t ** ptrL, void(*ptrF)(void *)){
  assert(ptrL && *ptrL);
  list_t * L = *ptrL;
  if(ptrF){
  	for(elmlist_t * E = L->head; E ; ){
  		elmlist_t * T = E;
  		E = E->suc;
  		(*ptrF)(T->datum);
  		free(T);
  	}
  } else {
  	for(elmlist_t * E = L->head; E ; ){
  		elmlist_t * T = E;
  		E = E->suc;
  		free(T);
  	}
  }
  free(*ptrL);
  (*ptrL) = NULL;
}

elmlist_t * get_head(list_t * L) {
  assert(L);
  return L->head;
}

void set_head( list_t * L, elmlist_t * E) {
	assert(L);
	L->head = E;
}

elmlist_t * get_tail(list_t * L) {
  assert(L);
  return L->tail;
}

void set_tail( list_t * L, elmlist_t * E) {
	assert(L);
	L->tail = E;
}

int get_numelm(list_t * L) {
  assert(L);
  return L->numelm;
}

void incrnumelm( list_t * L) {
	assert(L);
	L->numelm++;
}

void decrnumelm( list_t * L) {
	assert(L);
	L->numelm--;
}

void cons(list_t * L, void * d) {
  elmlist_t * E = calloc(1, sizeof(elmlist_t));
  assert(L && E);

  // on crée le maillon (précédent vide et successeur tete)
  set_data(E, d);
  set_suc(E, L->head);
  set_pred(E, NULL);

  // On chaîne le nouveau maillon en tête
  if(empty_list(L)) {
    // ce maillon est la nouvelle tete et la nouvelle queue
    set_head(L, E);
    L->tail = E;
  }
  else {
    // le nouveau maillon devient le précédent de la tete actuelle
    set_pred(get_tail (L), E);
    // le nouveau maillon devient la tête
    set_head(L, E);
  }

  // 1 élément de plus ...
  L->numelm += 1;
}

void queue(list_t * L, void * d){
  assert(L);
  if(empty_list(L)){
    cons(L, d);
  }
  else{
    elmlist_t * E = new_elmlist(d);
    set_suc(E,NULL);
    set_pred(E, get_tail (L));
    set_suc(L->tail, E);
    set_tail (L, E);
    L->numelm += 1;
  }
}

void view_list (list_t * L, void(*ptrF)(void *)){
  assert(L && ptrF);
  for(elmlist_t * E = L->head; E; E = get_suc(E)){
    void * d = E->datum;
    (*ptrF)(d);
  }
}

void insert_ordered(list_t * L, void * d, int (*ptrF_cmp)(void *, void *)) {
  // Vérifie que le pointeur vers la liste est valide
  assert(L);

  // Si la liste est vide ou si 'd' doit être placé avant le premier élément
  if (empty_list(L) || (*ptrF_cmp)(d, get_data(get_head(L))) <= 0) {
      // On insère 'd' au début de la liste
      cons(L, d);
  } 
  // Si 'd' doit être placé après le dernier élément
  else if ((*ptrF_cmp)(d, get_data(get_tail(L))) >= 0) {
      // On insère 'd' à la fin de la liste
      queue(L, d);
  } 
  else {
      // Sinon, on cherche la bonne position pour insérer 'd' en maintenant l'ordre

      // On part du début de la liste
      elmlist_t * E = get_head(L);

      // On avance jusqu'à trouver la position juste avant celle où 'd' doit aller
      while((*ptrF_cmp)(d, get_data(get_suc(E))) > 0) {
          E = get_suc(E);
      }

      // On insère 'd' juste après E
      insert_after(L, d, E);
  }
}

void quick_sort(list_t * L, int (*cmpFct)()){
  assert(L && cmpFct);

  if(L->numelm > 1){
      elmlist_t * pivot = get_head(L);
      L->head = get_suc(pivot); // reste(L)
      pivot->pred = NULL;
      pivot->suc = NULL;

      list_t * val_inf_pivot = new_list();
      list_t * val_sup_pivot = new_list();

      partition(L,pivot,val_inf_pivot,val_sup_pivot,cmpFct);
      /*
      /// On supprimer les éléments de L sans supprimer ni L ni les jobs
      elmlist_t * S;
      for(elmlist_t * E = L->head; E; E = S){
          S = E->suc;
          free(E);
      }
      */
      /** @note
       * Si la partie inf est vide alors L commence par le pivot
       * Sinon on tri grâce à cmpFct la partie inf puis on ajoute en queue le pivot
       */
      if(is_empty(val_inf_pivot)){
          L->head = pivot;
          L->tail = pivot;
          L->numelm = 1;
      }else{
          quick_sort(val_inf_pivot,cmpFct);
          L->head = val_inf_pivot->head;
          L->tail = val_inf_pivot->tail;
          L->numelm = val_inf_pivot->numelm;
          pivot->pred= L->tail;
          L->tail->suc = pivot;
          L->tail = pivot;
          L->numelm += 1;
      }
      /** @note
       * Si la partie sup n'est pas vide alors
       * On la trie puis on la concatène à la partie inf
       */
      if(!is_empty(val_sup_pivot)){
          quick_sort(val_sup_pivot,cmpFct);
          val_sup_pivot->head->pred = pivot;
          set_suc(pivot, val_sup_pivot->head);
          L->tail = val_sup_pivot->tail;
          L->numelm += val_sup_pivot->numelm;
      }
      free(val_inf_pivot);
      free(val_sup_pivot);
  }
}


/***********************************
 * Définitions des fonctions privées
 ***********************************/

 void insert_after(list_t * L, void * d, elmlist_t * place) {
  // Si la liste est vide ou si la position 'place' est invalide
  if(empty_list(L) || !place){
      // On insère simplement l'élément au début de la liste
      cons(L, d);
  }
  // Si 'place' correspond au dernier élément de la liste
  else if(place == get_tail(L)){
      // On insère l'élément à la fin de la liste
      queue(L, d);
  }
  else {
      // Sinon, on insère l'élément entre 'place' et son successeur

      // Création d’un nouvel élément de liste avec les données 'd'
      elmlist_t * E = new_elmlist(d); 

      // On définit le prédécesseur du nouvel élément comme 'place'
      set_pred(E, place);

      // On définit le successeur du nouvel élément comme le successeur de 'place'
      set_suc(E, get_suc(place));

      // On met à jour le successeur de 'place' pour qu’il pointe sur le nouvel élément
      set_suc(place, E);

      // On incrémente le nombre d’éléments dans la liste
      L->numelm += 1;
  }
}



void partition(list_t * L, elmlist_t * R, list_t * B, list_t * H, int (*cmpFct)()){
  elmlist_t * E, *next;
  
  assert(L && R && B && H && cmpFct);
  
  // On prend la tête de L pour le premier test
  E = get_head(L);

  while (E) {
    // on prend le suivant de E pour la prochaine itération
    next = get_suc (E);

    if(cmpFct(get_data(E), get_data(R)) <= 0){
      // on ajoute E dans la liste B Below
      addHeadElmt (E, B);
    }
    else{
      // on ajoute E dans la liste H High
      addHeadElmt (E, H);
    }

    // On passe à la valeur suivante
    E = next;
  }

  // L est maintenant vide
  L = new_list();
}

// find retrouve le job J (*PtrKey) dans la liste L des jobs grâce à la fonction cmpFct qui en fait
// compare les title
// Si ce job n'est pas dans la liste G alors
//    le job pointé par *PtrKey est enregistré dans G
// Si ce job est déjà dans G alors
//    le job pointé par *PtrKey est supprimé grâce à free_job
//    puis le pointeur de *PtrKey est réassigné sur le job trouvé dans G
void find(list_t * L, void ** ptrKey, int (*cmpFct)(), void (*delFct)()) {
  assert(L && ptrKey && cmpFct);

  elmlist_t * E = get_head(L);
  while(E && (cmpFct(*ptrKey, get_data(E)) > 0 || cmpFct(*ptrKey, get_data(E)) < 0)) {
      E = get_suc(E);
  }
  
  if(E){
      // Si E est non nul, E représente l'élément recherché
      // on fait pointer ptrKey dessus après avoir libéré
      // la data de recherche
      delFct(ptrKey);
      *ptrKey = get_data(E);
  }
  else 
      // sinon on l'ajoute en queue
      // la data de recherche pointe sur l'élément de la liste
      queue(L, *ptrKey);
}

// ROMAIN*************************************************************************************
// Take out the data D of the list L if it is present
void take_out(list_t * L, void * D)
{
  elmlist_t * E = get_head(L);

  // on parcourt
  while(E) {
      if ( D == get_data(E)) {
        // on a trouvé le job à retirer

        // on retire le job
        removeElmt (&E, L, NULL);

        // si on a trouvé le job on s'arrête, le travail est fait
        return;
      }
      else {
          E = get_suc(E);
      }
  }  
}

// ROMAIN
void addHeadElmt(elmlist_t * E, list_t * L){
  // E sera à la tête, donc prédécesseur vide
  set_pred (E, NULL);

  // on chaine E avec la tête actuelle
  set_suc(E, get_head (L));

  if(empty_list(L)) {
    // la liste L est vide, E devient la tête et la queue
    set_head(L, E);
    set_tail(L, E);
  }
  else {
      // on chaine le prédecesseur de la tete actuelle avec E
      set_pred(get_head (L), E);
      // E devient la tête
      set_head(L, E);
  }

  // L contient un élément de plus
  L->numelm += 1;
}

// ROMAIN

void removeElmt(elmlist_t ** E, list_t * L, void (*delFct)()) {
  if( get_pred(*E) == NULL) {
    // Tete de liste
    if ( get_suc(*E) == NULL) {
      // Tete/Queue de la liste reduite a une valeur
      // la liste devient vide
      set_head(L, NULL);
      set_tail(L, NULL);
    }
    else {
      // tete de liste avec au moins deux valeurs
      // la nouvelle tete est le successeur de E
      set_head(L, get_suc(*E));
      // et son prédecesseur devient vide
      set_pred(get_suc(*E), NULL);
    }
  }
  else {
    if ( get_suc(*E) == NULL) {
      // Queue de la liste avec au moins deux valeurs
      // la nouvelle tete est le successeur de E
      set_tail(L, get_pred(*E));
      // et son prédecesseur devient vide
      set_suc(get_pred(*E), NULL);
    }
    else {
      // dans une liste avec au moins trois valeurs
      // on rechaine predecesseur et successeur de E
      set_suc(get_pred(*E), get_suc(*E));
      set_pred(get_suc(*E), get_pred(*E));
    }
  }
  // un élément de moins dans la liste
  L->numelm -= 1;
  // on supprime l'élément retiré de la liste
  del_elmlist(E, delFct);
}