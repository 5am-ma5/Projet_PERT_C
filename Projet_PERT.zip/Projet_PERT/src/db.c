#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions


list_t * read_list( file_mode_t mode, void * (*read_fct) (), void (*del_fct) () ) {
	FILE * fd;
	char fname[20];
	list_t * L = new_list();
	
	if (mode == TEXT) {// Open file in TEXT mode
		printf( "\t\tRead list from text file (.txt)\n\tfile name :" );
		scanf( "%s", fname );
		fd = fopen( fname, "rt" );
	}
	else {// open file in BIN mode
		printf( "\t\tRead list from binary file (.bin)\n\tfile name :" );
		scanf( "%s", fname );
		fd = fopen( fname, "rb" );
	}
	/** @TODO parcourir le fichier pour y collecter les formulaires et les ranger dans la L
		ATTENTION :
			il est **possible** que vous créiez un élément de trop (un formulaire vide) en fin de liste.
			Il faut alors penser à le supprimer grâce au code suivant :
				E = get_tail (L);
				struct elmlist * T = getPred(E);
				set_suc(T, NULL);
				L->tail = T;
				del_elmlist(E, ptr_del);
	*/
	while ( !feof ( fd ) ) {
		// lire le formulaire
		void * T = (*read_fct)(fd, mode);
		// insérer le formulaire dans la liste
		cons(L,T);
	}
	// supprimer le dernier élément si nécessaire
	if () {
		E = get_tail (L);
		struct elmlist * T = getPred(E);
		set_suc(T, NULL);
		L->tail = T;
		del_elmlist(E, ptr_del);
	}

	fclose(fd);
	return L;
}
void write_list( list_t * L, file_mode_t mode, void (*write_fct) () ) {
	FILE * fd;
	char fname[20];
	if (mode == TEXT) {
		printf( "\t\tWrite list to text file (.txt)\n\tfile name :"), scanf( "%s", fname );
		fd = fopen( fname, "wt" );
	} else {
		printf("\t\tWrite list to binary file (.bin)\n\tfile name :"), scanf( "%s", fname );
		fd = fopen(fname, "wb" );
	}
	/// @todo Parcourir L et écrire les formulaires grâce à data_write_fct
	for (elmlist_t * E = get_head(L); E; E = get_suc(E)) {
		(*write_fct)(fd, get_data(E), mode);
	}
	node_t *current = L->head;  // Supposons que list_t possède un pointeur vers la tête de liste
    while (!empty_list(current)) {
        (*write_fct)(fd, get_data(current), mode);
        current = current->suc;;
    }
	fclose(fd);
}

