#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions
#include "elmlist.h"
#include "list.h"
#include "io.h"
#include "job.h"
#include "rank.h"

int main(int argc, char ** argv){
    if(argc < 2) exit(-1);

    list_t * G = read_graph(argv[1]);
    printf("Liste des tâches lue\n");
    view_list(G, &view_job);
   
    printf("Liste des tâches triée par degré d'entrée croissant\n");
    quick_sort(G, &iDegreeJobCmp);
    view_list(G,&view_job);

    printf("Liste des tâches triée par rang croissant\n");
    ranking(G);
    view_list(G,&view_job);

    printf("Prune edges\n");
    prune(G);
    view_list(G,&view_job);

    printf("\nMarges totales des tâches\n");
    marges(G);
    view_list(G,&view_job);

    return 0;
}
