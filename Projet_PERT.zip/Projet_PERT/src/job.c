#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "job.h"
#include "list.h"
#include "elmlist.h"
#include "outils.h"

job_t * new_empty_job ( ) {
    job_t * J = calloc ( 1, sizeof (job_t ) );
    assert( J );
    J->precedence = new_list ( );
    J->posteriority = new_list ( );
    J->rank = UNDEF;
    J->au_plus_tard = UNDEF;
    J->au_plus_tot = UNDEF;
    J->marge_totale = UNDEF;
    // ROMAIN *******************

    J->marge_libre = UNDEF;

    // ROMAIN *******************
    J->critique = false;
    return J;
}

job_t * new_job ( char * title ) {
    job_t * J = new_empty_job ( );
    J->title = strdup ( title );
    return J;
}

void free_job(job_t ** ptrJ ) {
    assert ( ptrJ && *ptrJ );
    if( (*ptrJ)->title ) free ( (*ptrJ)->title );
    free ( *ptrJ );
    *ptrJ = NULL;
}

void view_job ( job_t * J ) {
    printf ( "JOB %s\n\tpreceeded by [", get_job_title ( J ) );
    for(elmlist_t * E = get_head ( J->precedence ); E; E = get_suc ( E ) ) {
        printf ( " %s", get_job_title ( get_data ( E ) ) );
    }
    printf ( " ]\n" );
    // if ( !get_numelm ( J->posteriority ) ) printf ( "\t" );
    printf ( "\tfollowed by [" );
    for(elmlist_t * E = get_head(J->posteriority); E; E = get_suc(E)){
        printf(" %s", get_job_title(get_data(E)));
    }
    printf ( " ]\n" );
    printf ( "\tiDeg=%d\toDeg=%d\tlife=%2.2lf", J->input_degree, J->output_degree, J->life );
    printf ( "\trank=" );
    if ( J->rank == UNDEF ) printf ( "U" ); else printf ( "%d", J->rank );
    printf ( "\tearly=" );
    if(J->au_plus_tot == UNDEF ) printf("U"); else printf ( "%2.2lf",J->au_plus_tot );
    printf ( "\tlate=" );
    if(J->au_plus_tard == UNDEF ) printf("U"); else printf ( "%2.2lf",J->au_plus_tard );
    printf ( "\ttotale= " );
    if ( J->marge_totale == UNDEF ) printf("U"); else printf ( "%2.2lf", J->marge_totale );
    // ROMAIN
    printf ( "\tlibre= " );
    if ( J->marge_libre == UNDEF ) printf("U"); else printf ( "%2.2lf", J->marge_libre );
    // ROMAIN
    printf ( "\tcritical= " );
    if ( J->critique ) printf("Y\n"); else printf ( "N\n" );
    
}

// ROMAIN

int iDegreeJobCmp(job_t * J1, job_t * J2) {
    if (J1->input_degree < J2->input_degree)
        return -1;
    else if (J1->input_degree > J2->input_degree)
        return 1;
    else
        return 0;
}

int rangJobCmp(job_t * J1, job_t * J2) {
    if (J1->rank < J2->rank)
        return -1;
    else if (J1->rank > J2->rank)
        return 1;
    else
        return 0;
}

int titleJobCmp(job_t * J1, job_t * J2) {
    return strcmp (J1->title, J2->title);
}

void incr_job_iDegree(job_t * J) {
    J->input_degree++;
}

void incr_job_oDegree(job_t * J) {
    J->output_degree++;
}

int get_job_rank(job_t * J) {
    return J->rank;
}

void set_rank(job_t * J, int rank) {
    J->rank = rank;
}

double get_job_life(job_t * J) {
    return J->life;
}

void set_job_life(job_t * J, double life) {
    J->life = life;
}


char * get_job_title(job_t * J) {
    return J->title;
}

double get_job_auPlusTot(job_t * J) {
    return J->au_plus_tot;
}

void set_auPlusTot(job_t * J, double date) {
    J->au_plus_tot = date;

}

double get_job_auPlusTard(job_t * J) {
    return J->au_plus_tard;
}
void set_auPlusTard(job_t * J, double date) {
    J->au_plus_tard = date;

}

double get_job_MT(job_t * J) {
    return J->marge_totale;
}
void set_MT(job_t * J, double marge) {
    J->marge_totale = marge;
    if (marge == 0)
        set_critical(J, true);

}

double get_job_MargeLibre(job_t * J) {
    return J->marge_libre;
}

void set_MargeLibre(job_t * J, double marge) {
    J->marge_libre = marge;
}

bool get_job_Critical(job_t * J) {
    return J->critique;
}

void set_critical(job_t * J, bool critique) {
    J->critique = critique;
}

