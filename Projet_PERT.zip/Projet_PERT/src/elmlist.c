#include <stdlib.h>
#include <assert.h>
#include "elmlist.h"
#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions

/**********************************
DÉFINITIONS DES FONCTIONS PUBLIQUES
**********************************/
elmlist_t * new_elmlist(void * d){
  elmlist_t * E = calloc(1,sizeof(elmlist_t));
  assert(E);
  E->datum = d;
  return E;
}

void del_elmlist(elmlist_t ** ptrE, void (*ptrf) ()) {
  assert(ptrE && *ptrE);
  if(*ptrf) (*ptrf)(&(*ptrE)->datum);
  free(*ptrE);
  *ptrE = NULL;
}

void * get_data(elmlist_t * E){
  assert(E);
  return E->datum;
}

void set_data(elmlist_t * E, void * d ){
  assert(E);
  E->datum = d;
}

elmlist_t * get_suc(elmlist_t * E){
  assert(E);
  return E->suc;
}

void set_suc(elmlist_t * E, elmlist_t * S){
  assert(E);
  E->suc = S;
}

elmlist_t * get_pred(elmlist_t * E){
  assert(E);
  return E->pred;
}

void set_pred(elmlist_t * E, elmlist_t * S){
  assert(E);
  E->pred = S;
}
