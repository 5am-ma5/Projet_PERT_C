#include <stdlib.h>
#include <stdio.h>

#define EPSILON 0.0000001

void printInteger(void * pi){
  int *i = (int *) pi;

  printf("La valeur est entière et vaut : %d\n", (*i));
}

void stefPrintInteger(int * i){
  printf("La valeur est entière et vaut : %d\n", (*i));
}

void rmInteger(void * i){
  free((int *) i);
}

void stefRmInteger(int * i){
  free(i);
}
int cmpInteger(void * pi, void * pj){
  int *i = (int *) pi;
  int *j = (int *) pj;

  return (*i) - (*j);
}

int stefCmpInteger(int * i, int * j){
  return (*i) - (*j);
}
void printDouble(void * pd){
  double *d = (double *) pd;

  printf("La valeur est réelle et vaut : %lf\n", (*d));
}

void stefprintDouble(double * d){
  printf("La valeur est réelle et vaut : %lf\n", (*d));
}

void rmDouble(void * d){
  free((double *) d);
}

void stefRmDouble(double * d){
  free(d);
}

int cmpDouble(double * pu, double * pv){
  double *u = (double *) pu;
  double *v = (double *) pv;

  if((*u) - (*v) < -EPSILON) return -1;
  if((*u) - (*v) > +EPSILON) return +1;
  return 0;
}

int stefCmpDouble(double * u, double * v){
  if((*u) - (*v) < -EPSILON) return -1;
  if((*u) - (*v) > +EPSILON) return +1;
  return 0;
}

void freeInt(int ** ptrI){
	free(*ptrI);
	*ptrI = NULL;
}
void freeDouble(double ** ptrD){
	free(*ptrD);
	*ptrD = NULL;
}
