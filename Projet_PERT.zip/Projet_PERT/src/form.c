#include <stdlib.h> // librairie standard
#include <stdio.h> // librairie input/output
#include <stdbool.h> // librairie du type booléen
#include <assert.h> // librairie d'assertions


struct form * read_form(FILE * fd, file_mode_t mode) {
  // fd is already open and mode is eq to TEXT or BINARY
  assert( hfd );
	
  // create a form
  form_t * F = calloc( 1, sizeof(struct form) );
  assert( F );
	
  if(mode == TEXT) { // either fd is a text file
    fscanf( fd, " %s", F->product );
    fscanf( fd, " %d", &(F->stock) );
    fscanf( fd, " %lf", &(F->pbt) );
  } else { // BINARY, or fd is a binary file
    fread( F, sizeof(form_t), 1, fd );
  }
  return F;
}
