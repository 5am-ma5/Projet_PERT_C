#pragma once

extern list_t * read_graph ( char * filename );