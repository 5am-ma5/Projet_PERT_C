#pragma once
#include "list.h"
#include "elmlist.h"
#define UNDEF -2
/** Des redondances possibles avec d'autres TAs ! */
typedef struct {
  char * title;                 // Nom de la tâche
  double life;                  // Durée de la tâche
  int input_degree;             // Son degré de dépendance
  int output_degree;            // Les tâches qui en dépendent
  int rank;                     // Rang de la tâche
  int dyn_input_degree;         // Facilité de prog
  list_t * precedence;   // Les tâches précédentes
  list_t * posteriority; // Les tâches ultérieures
  double au_plus_tot;           // Date au plus tôt
  double au_plus_tard;          // Date au plus tard
  double marge_totale;          // Marge totale
  double marge_libre;           // Marge libre
  bool critique;                // Une tâche critique ?
} job_t;




job_t * new_empty_job();
job_t * new_job(char * title);
void free_job(job_t ** ptrJ);

void view_job(job_t * J);

char * get_job_title(job_t * J);
void set_job_title(job_t * J, char * title);

double get_job_life(job_t * J);
void set_job_life(job_t * J, double life);


int get_job_iDegree(job_t * J);
void set_job_iDegree(job_t * J, int iDegree);
void incr_job_iDegree(job_t * J);
void decr_job_iDegree(job_t * J);

int get_job_oDegree(job_t * J);
void set_job_oDegree(job_t * J, int oDegree);
void incr_job_oDegree(job_t * J);
void decr_job_oDegree(job_t * J);

int get_job_rank(job_t * J);
void set_rank(job_t * J, int rank);

int titleJobCmp(job_t * J1, job_t * J2);
int iDegreeJobCmp(job_t * J1, job_t * J2);
int oDegreeJobCmp(job_t * J1, job_t * J2);
int rangJobCmp(job_t *J1, job_t * J2);

// ROMAIN
double get_job_auPlusTot(job_t * J);
void set_auPlusTot(job_t * J, double date);

double get_job_auPlusTard(job_t * J);
void set_auPlusTard(job_t * J, double date);

double get_job_MT(job_t * J);
void set_MT(job_t * J, double marge);

double get_job_MargeLibre(job_t * J);
void set_MargeLibre(job_t * J, double marge);

bool get_job_Critical(job_t * J);
void set_critical(job_t * J, bool critique);
