#pragma once

void ranking(list_t * G);   // rangs de chaque sommets



void prune(list_t * G);     // enlève les arcs inutiles (si difference superieur a 1 alors inutiles) 



void marges(list_t * G);    // marges de temps autorisés pour chaque tâches 


// ROMAIN
void creationAlpha(list_t * L );

void creationOmega(list_t * L );

// tout cela expliquer dans le pdf du projet (sauf "prune" pas trouver.... mais expliquer par prof)


// les 3 fonctions a faire
// plus les fonctions dont nous avons besoins dans job.h 
// ne pas tout faire seulement celles utilise dans les fonctions faite par nous)