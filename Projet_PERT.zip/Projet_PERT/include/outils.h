#pragma once

/** Fonctions :
- D'affichage d'une valeur entière,
- De suppression d'une mémoire de type entier,
- De comparaison de 2 entiers.
 */
void printInteger(void * i);
void rmInteger(void * i);
int cmpInteger(void * i, void * j);

/** Fonctions :
- D'affichage d'une valeur réelle,
- De suppression d'une mémoire de type réel,
- De comparaison de 2 réels.
 */
void printDouble(void * d);
void rmDouble(void * d);
int cmpDouble(void * u, void * v);
void freeInt(int ** ptrI);
void freeDouble(double ** ptrD);
