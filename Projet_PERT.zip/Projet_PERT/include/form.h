#pragma once
/**
Form of manufactured products modeled with:
- A product name (char *)
- A stock (int)
- A price before tax (double)
*/
#define len_max 20
typedef struct form {
  char product[len_max];
  int stock;
  double pbt;
} form_t;

/** @brief Delete a form */
void del_form ( form_t * * F );

/** @brief Read a form from FILE */
form_t * read_form ( FILE * fd, file_mode_t mode );

/** @brief Write a form to FILE */
void write_form ( form_t * F, file_mode_t mode, FILE * fd );

/** @brief Get the product name of the form F */
char * get_product( form_t * F );

/** @brief Get the stock of the form F */
int get_stock ( form_t * F );

/** @brief Get the price before tax of the form F */
double get_price ( form_t * F);

/** @brief Display a form on stdout stream */
void view_form ( form_t * F);

/**  @brief Compare F1's product name with F2's product name */
int cmp_form ( form_t * F1, form_t * F2);
