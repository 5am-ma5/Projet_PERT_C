#pragma once
/* file mode : text or binary */
typedef enum file_mode { TEXT, BINARY } file_mode_t;

/** 
 * @brief read a list from a text or binary file acording to the mode 
 * @param mode : TEXT or BIN
 * @param data_read_fct : ptr to fct that reads datum from file fd ; fct's parameters : (fd, mode)
 * @param del_fct : ptr to fct that deallocate datum's memory, ; fct's parameter (datum)
 */
list_t * read_list ( file_mode_t mode, void * (*read_fct) (), void (*del_fct) () );


/** 
 * @brief write a list into a text or binary file acording to the mode
 * @param mode : TEXT or BIN
 * @param data_write_fct : ptr to fct that writes datum into file fd ; fct's parameters : (datum, fd, mode)
 */
void write_list ( list_t * L, file_mode_t mode, void (*write_fct) () );